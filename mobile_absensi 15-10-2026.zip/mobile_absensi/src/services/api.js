/**
 * API Client Service untuk Mobile Aku Hadir
 * Terhubung langsung ke Backend Laravel REST API (/api/mobile/*)
 */

const API_BASE = (typeof window !== 'undefined' && (window.location.port === '5173' || window.location.port === '8181'))
  ? '/api/mobile'
  : (typeof window !== 'undefined' && (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1'))
    ? 'https://panel.habtara.com/api/mobile'
    : '/api/mobile';

// Kunci Otorisasi REST API Resmi Aku Hadir Mobile
export const DEFAULT_API_KEY = 'SP-LIVE-9A8B7C6D5E4F3210';

export function getApiKey() {
  return localStorage.getItem('smart_presensi_api_key') || DEFAULT_API_KEY;
}

export function setApiKey(key) {
  if (key) {
    localStorage.setItem('smart_presensi_api_key', key);
  } else {
    localStorage.removeItem('smart_presensi_api_key');
  }
}

// Sinkronisasi Waktu Server Laravel (WIB Asia/Jakarta)
let serverTimeOffset = 0;

export function setServerTime(serverTimestamp) {
  if (serverTimestamp) {
    serverTimeOffset = Number(serverTimestamp) - Date.now();
  }
}

export function getServerDate() {
  return new Date(Date.now() + serverTimeOffset);
}

export function formatTime24(dateObj) {
  const d = dateObj || getServerDate();
  return d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
}

// Helper Device ID unik per peramban/perangkat
export function getOrCreateDeviceId() {
  let deviceId = localStorage.getItem('smart_presensi_device_id');
  if (!deviceId) {
    if (typeof crypto !== 'undefined' && crypto.randomUUID) {
      deviceId = 'DEV-' + crypto.randomUUID().toUpperCase();
    } else {
      const randPart = Math.random().toString(36).substring(2, 10).toUpperCase();
      const timePart = Date.now().toString(36).toUpperCase();
      deviceId = `DEV-${randPart}-${timePart}`;
    }
    localStorage.setItem('smart_presensi_device_id', deviceId);
  }
  return deviceId;
}

export function getDeviceModelName() {
  if (typeof navigator === 'undefined') return 'Mobile Web Client';
  const ua = navigator.userAgent;
  if (/iPhone/i.test(ua)) return 'Apple iPhone';
  if (/iPad/i.test(ua)) return 'Apple iPad';
  if (/Android/i.test(ua)) {
    const match = ua.match(/Android.*?; ([^;)]+)(?:;|\))/);
    if (match && match[1] && !match[1].includes('K')) return match[1].trim();
    return 'Android Smartphone';
  }
  if (/Windows/i.test(ua)) return 'Windows PC Client';
  if (/Macintosh/i.test(ua)) return 'macOS Client';
  return 'Smart Mobile Client';
}

export function setCustomDeviceId(deviceId) {
  localStorage.setItem('smart_presensi_device_id', deviceId);
}

// Token & Session Storage (Permanen kecuali logout)
export function getToken() {
  return localStorage.getItem('smart_presensi_token') || '';
}

export function setToken(token) {
  if (token) {
    localStorage.setItem('smart_presensi_token', token);
  } else {
    localStorage.removeItem('smart_presensi_token');
  }
}

export function getStoredUser() {
  try {
    const raw = localStorage.getItem('smart_presensi_user');
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function setStoredUser(user) {
  if (user) {
    localStorage.setItem('smart_presensi_user', JSON.stringify(user));
  } else {
    localStorage.removeItem('smart_presensi_user');
  }
}

export function clearAuth() {
  localStorage.removeItem('smart_presensi_token');
  localStorage.removeItem('smart_presensi_user');
}

/**
 * Universal Fetcher dengan handling Auth Header & Device Lock
 */
async function request(endpoint, options = {}) {
  const token = getToken();
  const apiKey = getApiKey();
  const deviceId = getOrCreateDeviceId();
  const headers = {
    'Accept': 'application/json',
    'X-API-KEY': apiKey,
    'X-DEVICE-ID': deviceId,
    ...(options.headers || {})
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  // Jika body adalah FormData, biarkan browser set multipart boundary
  if (options.body && !(options.body instanceof FormData)) {
    headers['Content-Type'] = 'application/json';
  }

  try {
    const res = await fetch(`${API_BASE}${endpoint}`, {
      ...options,
      headers
    });

    const data = await res.json().catch(() => ({}));

    if (!res.ok) {
      const isInactive = (res.status === 403 && (data.account_inactive || data.message?.toLowerCase().includes('nonaktif')));
      if (res.status === 401 || isInactive) {
        clearAuth();
        if (isInactive && typeof window !== 'undefined') {
          window.dispatchEvent(new CustomEvent('account-deactivated', {
            detail: {
              message: data.message || 'Status pegawai Anda telah dinonaktifkan oleh administrator.'
            }
          }));
        }
      }
      const error = new Error(data.message || 'Terjadi kesalahan pada server');
      error.status = res.status;
      error.data = data;
      throw error;
    }

    return data;
  } catch (err) {
    throw err;
  }
}

export const api = {
  /**
   * Login Pegawai
   */
  async login(credentials) {
    const deviceId = getOrCreateDeviceId();
    const deviceModel = getDeviceModelName();
    const payload = {
      login: credentials.login,
      password: credentials.password,
      device_id: credentials.device_id || deviceId,
      model_perangkat: credentials.model_perangkat || deviceModel,
      versi_os: navigator.userAgent.includes('Android') ? 'Android' : (navigator.userAgent.includes('iPhone') ? 'iOS' : 'Web/PWA'),
      versi_aplikasi: 'v1.1.0'
    };

    const res = await request('/login', {
      method: 'POST',
      body: JSON.stringify(payload)
    });

    if (res.token) {
      setToken(res.token);
    }
    if (res.pegawai) {
      setStoredUser(res.pegawai);
    }

    return res;
  },

  /**
   * Ambil data profil pegawai
   */
  async getMe() {
    return await request('/me');
  },

  /**
   * Ambil data ringkasan evaluasi KPI periode terbaru pegawai
   */
  async getKpiTerbaru() {
    return await request('/kpi/saya-terbaru');
  },

  /**
   * Ambil data dashboard riil (profil, jam kerja, absensi hari ini, statistik, riwayat)
   */
  async getDashboard() {
    const res = await request('/dashboard');
    if (res.server_time?.timestamp) {
      setServerTime(res.server_time.timestamp);
    }
    return res;
  },

  /**
   * Ambil data titik lokasi kantor & radius acuan terbaru secara realtime (Force Sync)
   */
  async getLokasiPresensi() {
    try {
      const res = await request(`/lokasi-presensi?_t=${Date.now()}`);
      if (res.server_time?.timestamp) {
        setServerTime(res.server_time.timestamp);
      }
      return res;
    } catch (err) {
      // Fallback ke getDashboard jika endpoint baru belum tersedia
      const fallback = await request(`/dashboard?_t=${Date.now()}`);
      return {
        success: fallback.success,
        lokasi_kantor: fallback.lokasi_kantor,
        semua_lokasi: fallback.semua_lokasi,
        ijinkan_wfa: fallback.pegawai?.ijinkan_wfa ?? false
      };
    }
  },

  /**
   * Kirim absensi masuk atau pulang
   */
  async absen(data) {
    return await request('/absen', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  },

  /**
   * Pencatatan Sesi Istirahat (mulai, selesai, lewati)
   */
  async catatIstirahat(aksi) {
    return await request('/absen/istirahat', {
      method: 'POST',
      body: JSON.stringify({ aksi })
    });
  },

  /**
   * Pendaftaran Wajah Master Pegawai (Biometric Face Enrollment)
   */
  async registerFace(data) {
    const res = await request('/face/register', {
      method: 'POST',
      body: JSON.stringify(data)
    });
    if (res.pegawai) {
      const currentUser = getStoredUser() || {};
      const updatedUser = { ...currentUser, ...res.pegawai };
      setStoredUser(updatedUser);
    }
    return res;
  },

  /**
   * Ambil riwayat absensi pegawai
   */
  async getRiwayat(bulan = null, tahun = null) {
    const params = new URLSearchParams();
    if (bulan) params.append('bulan', bulan);
    if (tahun) params.append('tahun', tahun);
    const qs = params.toString() ? `?${params.toString()}` : '';
    return await request(`/riwayat${qs}`);
  },

  /**
   * Logout pegawai
   */
  async logout() {
    try {
      await request('/logout', { method: 'POST' });
    } finally {
      clearAuth();
    }
  },

  /**
   * Layanan 1: Izin & Cuti Pegawai
   */
  async getIzin() {
    return await request('/izin');
  },

  async ajukanIzin(data) {
    const isFormData = data instanceof FormData;
    return await request('/izin', {
      method: 'POST',
      body: isFormData ? data : JSON.stringify(data)
    });
  },

  /**
   * Layanan 2: Kunjungan Dinas Luar
   */
  async getDinas() {
    return await request('/dinas');
  },

  async ajukanDinas(data) {
    const isFormData = data instanceof FormData;
    return await request('/dinas', {
      method: 'POST',
      body: isFormData ? data : JSON.stringify(data)
    });
  },

  /**
   * Layanan 3: Lembur Pegawai
   */
  async getLembur() {
    return await request('/lembur');
  },

  async ajukanLembur(data) {
    return await request('/lembur', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  },

  /**
   * Layanan 4: Jadwal Kerja & Shift
   */
  async getJadwal() {
    return await request('/jadwal');
  },

  /**
   * Layanan 5: Informasi Aturan Denda & Akumulasi Denda
   */
  async getDenda() {
    return await request('/denda');
  },

  /**
   * Layanan 6: Ubah Kata Sandi Akun
   */
  async changePassword(data) {
    return await request('/change-password', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  },

  /**
   * Layanan 7: Slip Gaji & Payroll Pegawai
   */
  async getSlipGaji() {
    return await request('/slip-gaji');
  },

  async getSlipGajiDetail(id) {
    return await request(`/slip-gaji/${id}`);
  },

  /**
   * Layanan 8: Ajukan Permasalahan & Kendala Presensi
   */
  async getMasalah() {
    return await request('/masalah');
  },

  async ajukanMasalah(data) {
    const isFormData = data instanceof FormData;
    return await request('/masalah', {
      method: 'POST',
      body: isFormData ? data : JSON.stringify(data)
    });
  },

  async getMasalahDetail(id) {
    return await request(`/masalah/${id}`);
  },

  /**
   * Pembaruan Foto Profil Mandiri Pegawai
   */
  async updateFotoProfil(data) {
    const isFormData = data instanceof FormData;
    const res = await request('/foto-profil', {
      method: 'POST',
      body: isFormData ? data : JSON.stringify(data)
    });
    if (res.foto_profil) {
      const currentUser = getStoredUser() || {};
      const updatedUser = { ...currentUser, foto_profil: res.foto_profil };
      setStoredUser(updatedUser);
    }
    return res;
  },

  /**
   * Layanan Penugasan Kerja & Kolaborasi (Tugas Berjalan & Tugas Selesai)
   */
  async getPenugasan() {
    return await request('/penugasan');
  },

  async getPenugasanDetail(id) {
    return await request(`/penugasan/${id}`);
  },

  async updateStatusPenugasan(id, data) {
    return await request(`/penugasan/${id}/status`, {
      method: 'POST',
      body: JSON.stringify(data)
    });
  },

  /**
   * Layanan Approval Bertingkat (Persetujuan Izin, Cuti, Lembur, Dinas)
   */
  async getApprovalCount() {
    return await request('/approval/count');
  },

  async getApprovals(tab = 'menunggu') {
    return await request(`/approval?tab=${tab}`);
  },

  async submitApprovalAction(id, data) {
    return await request(`/approval/${id}/action`, {
      method: 'POST',
      body: JSON.stringify(data)
    });
  },

  /**
   * Layanan In-App Preview Dokumen Pendukung (Surat Dokter & Surat Tugas Dinas)
   */
  async getDokumenPreview(modul, id) {
    return await request(`/dokumen/preview/${modul}/${id}`);
  },

  /**
   * Layanan Pengumuman & Broadcast Perusahaan
   */
  async getPengumumanCount() {
    return await request('/pengumuman/count');
  },

  async getPengumuman(filter = 'semua') {
    return await request(`/pengumuman?filter=${filter}`);
  },

  async getPengumumanDetail(id) {
    return await request(`/pengumuman/${id}`);
  },

  /**
   * Layanan Klaim & Reimbursement Pegawai
   */
  async getReimbursementJenis() {
    return await request('/reimbursement/jenis');
  },

  async getReimbursement() {
    return await request('/reimbursement');
  },

  async ajukanReimbursement(data) {
    const isFormData = data instanceof FormData;
    return await request('/reimbursement', {
      method: 'POST',
      body: isFormData ? data : JSON.stringify(data)
    });
  },

  async getReimbursementDetail(id) {
    return await request(`/reimbursement/${id}`);
  },

  /**
   * Layanan Monitoring Kehadiran Bawahan (Atasan)
   */
  async getKehadiranBawahanStatus() {
    return await request('/kehadiran-bawahan/status');
  },

  async getKehadiranBawahanList(bulan = null) {
    const qs = bulan ? `?bulan=${bulan}` : '';
    return await request(`/kehadiran-bawahan${qs}`);
  },

  async getKalenderBawahan(bawahanId, bulan = null) {
    const qs = bulan ? `?bulan=${bulan}` : '';
    return await request(`/kehadiran-bawahan/${bawahanId}/kalender${qs}`);
  },

  /**
   * Layanan Tukar Shift Roster
   */
  async getTukarShiftCount() {
    return await request('/tukar-shift/count');
  },

  async getTukarShiftInisiasi() {
    return await request('/tukar-shift/inisiasi');
  },

  async getTukarShiftJadwalRekan(rekanId) {
    return await request(`/tukar-shift/rekan/${rekanId}/jadwal`);
  },

  async ajukanTukarShift(data) {
    return await request('/tukar-shift', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  },

  async getTukarShiftRiwayat() {
    return await request('/tukar-shift/riwayat');
  },

  async responTukarShift(id, aksi, catatan = null) {
    return await request(`/tukar-shift/${id}/respon`, {
      method: 'POST',
      body: JSON.stringify({ aksi, catatan })
    });
  },

  async batalkanTukarShift(id) {
    return await request(`/tukar-shift/${id}/batalkan`, {
      method: 'POST'
    });
  }
};

export default api;

